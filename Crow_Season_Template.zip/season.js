CrowContent.registerSeason({
  id: 'season-03',
  title: 'فصل سوم — نامه‌ی خاکستر',
  install(api) {
    api.addClue('s3_archive_note', {
      n: 'نامه‌ی سوخته',
      d: 'روی لبه‌ی خاکستر، شماره‌ی صندوق و ساعتِ تحویل خوانده می‌شود.'
    });

    api.addDialogue('s3_intro', [
      ['a', 'بایگانیِ متروک. کسی بعد از نیمه‌شب این‌جا بوده است.'],
      ['a', 'اگر نامه را پیدا کنم، شاید بفهمم چه کسی پرونده را جابه‌جا کرده.']
    ]);
    api.addDialogue('s3_note', [
      ['a', 'کاغذ سوخته است، اما مُهر و ساعت هنوز خواناست.'],
      { s: 'a', t: 'شماره‌ی صندوق و زمان تحویل را ثبت می‌کنم.', give: 's3_archive_note' }
    ]);
    api.addDialogue('s3_repeat', [['a', 'نامه را قبلاً بررسی کرده‌ام.']]);
    api.addDialogue('s3_missing', [['a', 'بدونِ نامه نمی‌توانم گزارش بدهم.']]);
    api.addDialogue('s3_report', [
      ['a', 'شماره‌ی صندوق با دفترِ ورود و خروج مطابقت دارد. این مسیر را دنبال می‌کنم.'],
      { end: 's3_good' }
    ]);
    api.addEnding('s3_good', {
      t: 'نامه‌ی خاکستر',
      s: 'یک رد تازه از شبکه پیدا شد.',
      c: '#d6ad65',
      good: true
    });

    api.addAction('s3_document', () => api.has('s3_archive_note') ? 's3_repeat' : 's3_note');
    api.addAction('s3_phone', () => api.has('s3_archive_note') ? 's3_report' : 's3_missing');

    api.addScene('s3_archive', (engine) => engine.buildScene({
      id: 's3_archive',
      name: 'بایگانیِ متروک — نیمه‌شب',
      w: 480,
      seed: 3303,
      indoor: true,
      spawn: 48,
      room: { wall: '#48434a', wall2: '#28252c', trim: '#8a795f', floor: 'wood', floorCol: '#3a2c27', ceil: '#17141b' },
      props: [
        ['desk', { x: 140, w: 75 }],
        ['shelf', { x: 300, y: 86, w: 70, h: 30 }],
        ['clockTall', { x: 420 }]
      ],
      npcs: [],
      lights: [
        { x: 160, y: 104, r: 120, c: [255, 185, 110], i: 0.8, f: 'lamp', z: 12 },
        { x: 340, y: 82, r: 80, c: [100, 145, 255], i: 0.3, f: 'bulb', z: 18 }
      ],
      targets: [
        { id: 's3_document', x: 160, y: 112, w: 28, h: 24, n: 'نامه‌ی سوخته' },
        { id: 's3_phone', x: 235, y: 116, w: 22, h: 42, n: 'تلفنِ داخلی' }
      ]
    }));

    api.addLevel({
      n: 'پرونده‌ی ۱۷',
      t: 'نامه‌ی خاکستر',
      s: 'بایگانیِ متروک، نیمه‌شب — چه کسی سند را پیش از سوزاندن جابه‌جا کرد؟',
      scene: 's3_archive',
      intro: 's3_intro',
      clock: 2700,
      file: 'پرونده‌ی نامه‌ی سوخته',
      nb: 'دفترچه — نامه‌ی خاکستر',
      clues: ['s3_archive_note'],
      goals: [
        { t: 'نامه‌ی سوخته را بررسی کن', id: 's3_document', done: () => api.has('s3_archive_note') },
        { t: 'با تلفن گزارش بده', id: 's3_phone', done: () => false }
      ],
      ded: () => api.has('s3_archive_note') ? ['شماره‌ی صندوق و ساعتِ تحویل ثبت شد.', 'می‌توانم گزارش بدهم.'] : ['هنوز مدرک کافی ندارم.']
    });
  }
});
